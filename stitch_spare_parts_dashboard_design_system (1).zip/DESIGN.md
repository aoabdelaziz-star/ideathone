---
name: VMS Industrie Precision Intelligence
colors:
  surface: '#f9f9ff'
  surface-dim: '#d8dae3'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3fd'
  surface-container: '#ecedf7'
  surface-container-high: '#e6e8f1'
  surface-container-highest: '#e0e2eb'
  on-surface: '#181c22'
  on-surface-variant: '#5d3f3c'
  inverse-surface: '#2d3037'
  inverse-on-surface: '#eef0fa'
  outline: '#926e6b'
  outline-variant: '#e7bdb8'
  surface-tint: '#c00015'
  primary: '#b90014'
  on-primary: '#ffffff'
  primary-container: '#e31b23'
  on-primary-container: '#fff9f8'
  inverse-primary: '#ffb4ac'
  secondary: '#5e5e62'
  on-secondary: '#ffffff'
  secondary-container: '#e3e2e6'
  on-secondary-container: '#646468'
  tertiary: '#7028e0'
  on-tertiary: '#ffffff'
  tertiary-container: '#894afb'
  on-tertiary-container: '#fff8ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ac'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#93000d'
  secondary-fixed: '#e3e2e6'
  secondary-fixed-dim: '#c7c6ca'
  on-secondary-fixed: '#1b1b1f'
  on-secondary-fixed-variant: '#46464a'
  tertiary-fixed: '#eaddff'
  tertiary-fixed-dim: '#d2bbff'
  on-tertiary-fixed: '#25005a'
  on-tertiary-fixed-variant: '#5a00c6'
  background: '#f9f9ff'
  on-background: '#181c22'
  surface-variant: '#e0e2eb'
  surface-canvas: '#f4f4f6'
  surface-card: '#ffffff'
  surface-dark: '#141518'
  surface-dark-elevated: '#1f2126'
  border-hairline: '#e3e5e8'
  border-strong: '#cbd0d6'
  brand-accent-deep: '#b91c1c'
  brand-soft: '#fde8e9'
  brand-indicator: '#ff4d54'
  status-ok: '#16a34a'
  status-ok-soft: '#eafbf1'
  status-warn: '#d97706'
  status-warn-soft: '#fff6e6'
  status-danger: '#dc2626'
  status-danger-soft: '#fef0f0'
  category-purple-soft: '#f4efff'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 29px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -1px
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.6px
  headline-lg:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.8px
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.4px
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 26px
    letterSpacing: -0.3px
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 22px
    letterSpacing: 0px
  section-title:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0px
  body-default:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 19px
  body-compact:
    fontFamily: Inter
    fontSize: 12.5px
    fontWeight: '400'
    lineHeight: 18px
  label-standard:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  meta-detail:
    fontFamily: Inter
    fontSize: 11.5px
    fontWeight: '400'
    lineHeight: 15px
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '650'
    lineHeight: 14px
    letterSpacing: 0.6px
  badge-caps:
    fontFamily: Inter
    fontSize: 10.5px
    fontWeight: '700'
    lineHeight: 13px
    letterSpacing: 0.4px
  nav-section-label:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 1.4px
  chart-axis:
    fontFamily: Inter
    fontSize: 9.5px
    fontWeight: '400'
    lineHeight: 12px
    letterSpacing: 0px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-compact: 0.5rem
  gutter-wide: 1.25rem
  margin: 1.75rem
  margin-mobile: 1.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

The design system is constructed for mission-critical automotive and industrial supply chain operations. The visual atmosphere balances authoritative engineering rigor with high-speed digital responsiveness. It serves plant directors, procurement leads, and inventory intelligence analysts who make high-stakes, capital-intensive decisions.

Drawing primarily from **Modern Industrial Corporate** with selective **Tactile / High-Performance accents**, the system merges structured data density with tactile operational feedback. A deep carbon sidebar anchors the viewport, while light, hairline-bordered surface tiles optimize legibility under varied factory and office lighting. High-visibility racing red functions as a decisive focal driver rather than decoration—directing eye gaze immediately to stock-outs, demand anomalies, and key commitments. Precision is reinforced through micro-interactions: cursor-responsive surface illumination, 3D parametric visualizations for inventory modeling, and deliberate slide-to-confirm mechanics for high-risk ERP operations.

## Colors

The chromatic structure is grounded in high-contrast technical utility:

- **Primary (`#e31b23`)**: Racing Red. Reserved strictly for primary action drivers, live inventory delta markers, selected navigation states, and interactive thresholds.
- **Secondary (`#141518`)**: Deep Carbon. Applied to the primary persistent navigation bar, high-contrast badges, avatar containers, and foundational dark elements.
- **Tertiary (`#7c3aed`)**: Precision Violet. Designates specialized analytical categories, belt and transmission telemetry, and high-tier predictive clusters.
- **Neutral (`#63666e`)**: Neutral Slate. Governs metadata, column headers, axis ticks, structural icons, and secondary descriptive text.

### Semantic Status Pairing
State indicators always employ matched-contrast pairings:
- **Critical / Danger**: `#dc2626` over `#fef0f0` with `#fecaca` border emphasis.
- **Warning / Alert**: `#d97706` over `#fff6e6`.
- **Nominal / Success**: `#16a34a` over `#eafbf1`.
- **System Neutral**: `#64748b` over `#f1f5f9`.

### Structural Division
Dividers operate on two explicit contrast levels: `border-hairline` (`#e3e5e8`) for ambient containment, table divisions, and card limits; and `border-strong` (`#cbd0d6`) for inputs, toggle boundaries, and hover-state focus lines.

## Typography

Typography is standardized on `Inter` with OpenType tabular figures (`font-feature-settings: "tnum" 1, "cv05" 1`) enabled system-wide. This ensures currency values, lead-time counters, and dimensional metrics align perfectly across operational tables and stat grids.

### Editorial Logic
- **Monospaced Behavior for Numerical Data**: Tables, stat displays, and KPI cards require proportional figures to maintain vertical column integrity.
- **Micro-Heading Hierarchy**: Section eyebrow labels, table column headers (`<th>`), and dark sidebar grouping names strictly enforce uppercase transformation with intentional wide tracking (`0.4px` to `1.4px`) to preserve legibility at sub-12px sizes.
- **Tone & Clarity**: Line heights favor dense scannability without visual crowding, allowing high information payload on standard 1080p and 1440p terminal screens.

## Layout & Spacing

The layout architecture implements a fixed-width navigational command rail paired with a fluid, multi-tier operational canvas capped at an optimal reading width of `1320px`.

### Global Shell Structure
- **Sidebar Rail**: Fixed `252px` wide, full height (`100vh`), non-collapsing on desktop.
- **Top Bar**: Sticky `64px` header with `backdrop-filter: blur(8px)`.
- **Canvas Margins**: `28px` horizontal margin on desktop views, compressing smoothly to `18px` below `720px`.

### Grid System & Breakpoints
- **Desktop (1050px+)**: 12-column dynamic CSS Grid with `16px` gutters. Standard composite cards deploy in 4-column metrics (`grid-template-columns: repeat(4, 1fr)`) or asymmetric intelligence configurations (2:1 or 1:2 splits).
- **Tablet (721px – 1049px)**:
  - 4-column metric grids collapse to 2 columns (`repeat(2, 1fr)`).
  - 3-column Kanban decision boards collapse to single-column vertical stacks.
  - Specialized 3D visualizer canvases shrink from `300px` to `240px`.
- **Mobile (≤ 720px)**:
  - All multi-column cards collapse to single-column (`1fr`).
  - Dark sidebar transitions from static viewport element to an overlay off-canvas drawer.
  - Sticky topbar padding reduces to `16px`.

## Elevation & Depth

Visual hierarchy relies on structural hairline delineation paired with targeted ambient illumination. Heavy drop shadows are avoided in favor of crisp boundaries suitable for industrial monitors.

### Elevation Hierarchy
- **Level 0 (Canvas)**: `#f4f4f6` matte background. Zero elevation.
- **Level 1 (Card & Section Containers)**: `#ffffff` surface encapsulated with a `1px` stroke of `#e3e5e8` and an ambient anchor shadow: `0 1px 2px rgba(20,21,24, 0.04), 0 8px 24px rgba(20,21,24, 0.06)`.
- **Level 2 (Hover & Interactive Lift)**: When cursor focus engages a decision card, the unit lifts via `transform: translateY(-3px)` supported by `0 18px 40px rgba(15,23,42, 0.10)`.
- **Level 3 (Sticky Navigation & Chrome)**: Sticky header utilizes frosted diffusion: `rgba(255, 255, 255, 0.86)` with `backdrop-filter: blur(8px)`.
- **Level 4 (Floating Dialogues & Modals)**: Critical commit dialogs command `0 24px 60px rgba(0,0,0, 0.25)` over a backdrop wash of `rgba(15, 23, 42, 0.50)`.
- **Level 5 (Toast System)**: Tactical execution notices float at `0 10px 30px rgba(0,0,0, 0.25)`.

### Dynamic Illumination
Interactive cards feature cursor-tracking ambient spotlights: a pseudo-element radial gradient `radial-gradient(circle 240px at var(--mx) var(--my), rgba(227, 27, 35, 0.11), transparent 80%)` creates live directional awareness without obscuring data legibility.

## Shapes

The design system embraces a functional, calibrated radius model (`level 2: Rounded`). Roundedness reflects mechanical precision rather than soft consumer playfulness:

- **Primary Cards & Containers**: `14px` exterior boundary radius.
- **Inner Panels & Modal Hosts**: `11px` to `12px` ensuring geometric concentricity inside parent containers.
- **Interactive Controls (Inputs, Buttons, Segmented Selectors)**: `9px` radius, matching standard touch and click geometry.
- **Micro Chips & Indicator Badges**: Full pill execution (`999px`) or tight `5px` radii for embedded quantitative counters.
- **Structural Bars & Sliders**: `8px` to `10px` capsules for progressive linear tracks.

## Components

### Buttons & Interactive Triggers
- **Primary Button**: Filled `#e31b23` with `#ffffff` text, `9px` radius, padding `8px 13px`. On hover, transitions to `#c8161d`.
- **Secondary Button**: `#ffffff` surface, `1px solid #e3e5e8` border, `#141518` typography. On hover, the border darkens to `#cbd0d6` with subtle lift.
- **Affirmative Button (`.btn-ok`)**: Solid `#16a34a` for non-critical confirmations.
- **Danger Button**: `#ffffff` background, `#dc2626` text, `1px solid #fecaca` border; hover activates `#fef0f0`.
- **Icon Actions**: Fixed `32x32px` square with `9px` radius, holding a centered `14x14px` or `15x15px` SVG.

### Form Inputs & Search Fields
- Base inputs, textareas, and select elements feature `9px` border radius, `#ffffff` fill, and `1px solid #cbd0d6` bounding line.
- Focus state invokes a crisp halo: `0 0 0 3px rgba(37, 99, 235, 0.12)` with a `#2563eb` or `#e31b23` border stroke depending on domain sensitivity.
- Labels sit above the field in uppercase tracking (`11px`, weight `650`, letter spacing `0.6px`, color `#63666e`).

### Status Badges & Chips
- Uniform height of `20px` to `22px` with `999px` full pill radius, padding `3px 8px`.
- Rendered in bold uppercase type (`10.5px`, weight `700`, letter spacing `0.3px`).
- Always combine a 10% opacity tinted fill (`*-soft`) with high-contrast text:
  - Critical: `#dc2626` on `#fef0f0`.
  - High Warning: `#d97706` on `#fff6e6`.
  - Nominal: `#16a34a` on `#eafbf1`.
  - Specialized Category: `#7c3aed` on `#f4efff`.

### Data Tables
- Header row (`<th>`): `#fafbfc` background, `10px 12px` padding, uppercase `10.5px` type with tracking, hairline border-bottom (`#e3e5e8`).
- Cell content (`<td>`): `11px 12px` padding, border-bottom `1px solid #f1f5f9`.
- Row hover triggers smooth `#fafcff` surface transition.
- Numerical columns right-align with active tabular figures (`font-variant-numeric: tabular-nums`).

### Slide to Approve (Commit Action)
- Designed for irreversible supply chain and ERP write mutations.
- Enclosed in an elongated track (`height: 44px`, radius `10px`, background `#f1f5f9`, border `1px solid #cbd0d6`).
- Interactive circular drag thumb (`height: 36px`, `width: 36px`, radius `8px`, `#16a34a` surface, holding affirmative check icon).
- Drag gesture fills the active track with `#dcfce7` to `#bbf7d0` gradient until 100% threshold confirms execution.

### Stat Tiles & KPI Cards
- Structure: Sub-heading eyebrow (`11px` uppercase), followed by the primary metric display (`26px`, weight `750`, tracking `-0.8px`), flanked by contextual percentage pills showing positive (`#16a34a`) or negative (`#dc2626`) variance.